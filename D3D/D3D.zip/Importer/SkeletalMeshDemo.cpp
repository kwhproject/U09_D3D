#include "stdafx.h"
#include "SkeletalMeshDemo.h"

void SkeletalMeshDemo::Initialize()
{
	shader = new Shader(L"16_SkeletalMesh.fxo");

	Tank();
}

void SkeletalMeshDemo::Destroy()
{
	SafeDelete(tank);
}

void SkeletalMeshDemo::Update()
{
	static Vector3 lightDirection = Vector3(-1, -1, 1);
	shader->AsVector("LightDirection")->SetFloatVector(lightDirection);
	ImGui::SliderFloat3("Light Direction", lightDirection, -1, 1);

	if (tank != nullptr)
		tank->Update();
}

void SkeletalMeshDemo::Render()
{
	if (tank != nullptr)
		tank->Render();
}

void SkeletalMeshDemo::Tank()
{
	tank = new SkeletalMeshRenderer(shader);
	tank->ReadMesh(L"Tank/Tank");
}
